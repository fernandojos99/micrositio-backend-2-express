import supabase from '../config/supabaseClient.js';

class FormatoRepository {
  static async create(formatoData) {
    const { document_name, document_url, document_type, categoria } = formatoData;
    
    const { data, error } = await supabase
      .from('formato')
      .insert([
        {
          document_name,
          document_url,
          document_type,
          categoria
        }
      ])
      .select()
      .single();
    
    if (error) throw error;
    return data;
  }

  static async findAll() {
    const { data, error } = await supabase
      .from('formato')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data;
  }

  static async findById(id) {
    const { data, error } = await supabase
      .from('formato')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) throw error;
    return data;
  }

  static async update(id, updateData) {
    // Solo actualizar los campos proporcionados
    const dataToUpdate = {
      ...updateData,
      updated_at: new Date().toISOString()
    };
    
    const { data, error } = await supabase
      .from('formato')
      .update(dataToUpdate)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  }

  static async delete(id) {
    const { data, error } = await supabase
      .from('formato')
      .delete()
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  }
}

export default FormatoRepository;